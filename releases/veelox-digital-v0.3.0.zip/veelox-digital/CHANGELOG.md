# Veelox Digital changelog

## Version 0.3.0 — Plans & Packages

- Added a working Plans & Packages navigation section.
- Added searchable package listing with billing and status filters.
- Added create, view and edit package screens.
- Added one-off, monthly and yearly billing options.
- Added setup fees with all monetary values stored safely as integer pence.
- Added package descriptions and ordered included-feature lists.
- Added public and internal-only visibility controls.
- Added active, inactive and archived package states.
- Added package duplication as an inactive copy.
- Added safe archiving without changing existing orders.
- Added order, active-order, customer and revenue totals for each package.
- Added package creation to dashboard quick actions.
- Added administrator and staff route permissions and CSRF protection.
- Added responsive desktop, tablet and mobile package layouts.
- Added a browser database updater for DirectAdmin hosting without SSH.

## Version 0.2.0 — Customer Management

- Added customer listing, search and status filters.
- Added customer creation, profiles, editing and archiving.
- Added internal notes, billing addresses and portal access creation.
- Added automatic Veelox customer account numbers.

## Version 0.1.0 — Foundation

- Added secure authentication, roles, dashboard and initial database schema.
- Added the browser-based DirectAdmin installer.
