<?php $outstanding = '£' . number_format($metrics['outstanding'] / 100, 2); ?>
<header class="page-header">
    <div>
        <div class="eyebrow">Overview</div>
        <h1>Good <?= (int) date('G') < 12 ? 'morning' : ((int) date('G') < 18 ? 'afternoon' : 'evening') ?>, <?= htmlspecialchars(explode(' ', (string) $user['name'])[0]) ?>.</h1>
        <p>Here’s what’s happening across Veelox Digital today.</p>
    </div>
    <?php if (($user['role'] ?? '') !== 'customer'): ?><a class="primary-button" href="/customers/create">+ Add customer</a><?php endif; ?>
</header>

<section class="metric-grid">
    <article class="metric-card"><span class="metric-icon lilac">◎</span><div><small>Active customers</small><strong><?= number_format($metrics['customers']) ?></strong><em>Customer accounts</em></div></article>
    <article class="metric-card"><span class="metric-icon blue">◇</span><div><small>Active orders</small><strong><?= number_format($metrics['orders']) ?></strong><em>Pending and active</em></div></article>
    <article class="metric-card"><span class="metric-icon amber">£</span><div><small>Outstanding</small><strong><?= htmlspecialchars($outstanding) ?></strong><em>Awaiting payment</em></div></article>
    <article class="metric-card"><span class="metric-icon green">✦</span><div><small>Open tickets</small><strong><?= number_format($metrics['tickets']) ?></strong><em>Need attention</em></div></article>
</section>

<section class="dashboard-grid">
    <article class="panel">
        <div class="panel-heading"><div><span class="eyebrow">Revenue</span><h2>Performance overview</h2></div><span class="pill">This month</span></div>
        <div class="empty-state"><span>↗</span><h3>Revenue reporting is ready</h3><p>Charts will populate as invoices and payments are recorded.</p></div>
    </article>
    <article class="panel quick-panel">
        <div class="panel-heading"><div><span class="eyebrow">Shortcuts</span><h2>Quick actions</h2></div></div>
        <?php if (($user['role'] ?? '') !== 'customer'): ?><a href="/customers/create"><span>◎</span><div><strong>Add a customer</strong><small>Create a new customer account</small></div><b>›</b></a><?php endif; ?>
        <?php if (($user['role'] ?? '') !== 'customer'): ?><a href="/packages/create"><span>▦</span><div><strong>Create a package</strong><small>Add a one-off or recurring service</small></div><b>›</b></a><?php endif; ?>
        <div class="quick-disabled"><span>◇</span><div><strong>Create an order</strong><small>Available in the next module</small></div><b>Soon</b></div>
        <div class="quick-disabled"><span>▤</span><div><strong>Raise an invoice</strong><small>Available in the billing module</small></div><b>Soon</b></div>
    </article>
</section>
