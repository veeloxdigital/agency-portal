# Veelox Digital changelog

## Version 0.4.0 — Customer Orders

- Replaced the customer dashboard with a private account-only overview; customers no longer see Veelox Digital performance or internal agency statistics.
- Added searchable customer order listing with status and billing filters.
- Added package-based and custom service orders.
- Added automatic package price, setup fee and billing defaults.
- Added per-order custom pricing without changing the package price.
- Added collision-safe yearly order numbers such as `ORD-2026-0001`.
- Added one-off, monthly and yearly billing terms.
- Added start and next-renewal dates.
- Added administrator and staff assignment.
- Added draft, pending, awaiting payment, paid, active, completed, cancelled and refunded workflows.
- Added order detail, edit and quick status-change screens.
- Added private internal order notes.
- Added order totals stored as integer pence.
- Added customer and package links from order records.
- Added responsive order layouts and a working dashboard shortcut.

## Version 0.3.0 — Plans & Packages

- Added a working Plans & Packages navigation section.
- Added searchable package listing with billing and status filters.
- Added create, view and edit package screens.
- Added one-off, monthly and yearly billing options.
- Added setup fees with all monetary values stored safely as integer pence.
- Added package descriptions and ordered included-feature lists.
- Added public and internal-only visibility controls.
- Added active, inactive and archived package states.
- Added package duplication as an inactive copy.
- Added safe archiving without changing existing orders.
- Added order, active-order, customer and revenue totals for each package.
- Added package creation to dashboard quick actions.
- Added administrator and staff route permissions and CSRF protection.
- Added responsive desktop, tablet and mobile package layouts.
- Added a browser database updater for DirectAdmin hosting without SSH.

## Version 0.2.0 — Customer Management

- Added customer listing, search and status filters.
- Added customer creation, profiles, editing and archiving.
- Added internal notes, billing addresses and portal access creation.
- Added automatic Veelox customer account numbers.

## Version 0.1.0 — Foundation

- Added secure authentication, roles, dashboard and initial database schema.
- Added the browser-based DirectAdmin installer.
