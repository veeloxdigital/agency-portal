<?php

declare(strict_types=1);

namespace App\Core;

use Throwable;

final class Application
{
    public function __construct(private readonly array $routes)
    {
    }

    public function run(): void
    {
        try {
            $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
            $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
            $path = '/' . trim($path, '/');
            $path = $path === '/' ? '/' : rtrim($path, '/');

            foreach ($this->routes as [$routeMethod, $routePath, $handler, $middleware]) {
                if ($method !== $routeMethod || $path !== $routePath) {
                    continue;
                }

                $this->runMiddleware($middleware);
                [$controller, $action] = $handler;
                (new $controller())->{$action}();
                return;
            }

            http_response_code(404);
            echo 'Page not found.';
        } catch (Throwable $exception) {
            http_response_code(500);
            if (Env::get('APP_DEBUG', false)) {
                echo '<pre>' . htmlspecialchars((string) $exception) . '</pre>';
            } else {
                echo 'Something went wrong. Please try again.';
            }
        }
    }

    private function runMiddleware(array $middleware): void
    {
        foreach ($middleware as $name) {
            if ($name === 'auth' && !Auth::check()) {
                $this->redirect('/login');
            }
            if ($name === 'guest' && Auth::check()) {
                $this->redirect('/');
            }
            if ($name === 'csrf' && !Csrf::verify($_POST['_token'] ?? null)) {
                http_response_code(419);
                exit('Your session expired. Please go back and try again.');
            }
        }
    }

    private function redirect(string $location): never
    {
        header('Location: ' . $location);
        exit;
    }
}
