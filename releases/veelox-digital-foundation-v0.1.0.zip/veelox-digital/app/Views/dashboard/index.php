<?php $outstanding = '£' . number_format($metrics['outstanding'] / 100, 2); ?>
<header class="page-header">
    <div>
        <div class="eyebrow">Overview</div>
        <h1>Good <?= (int) date('G') < 12 ? 'morning' : ((int) date('G') < 18 ? 'afternoon' : 'evening') ?>, <?= htmlspecialchars(explode(' ', (string) $user['name'])[0]) ?>.</h1>
        <p>Here’s what’s happening across Veelox Digital today.</p>
    </div>
    <button class="primary-button" type="button">+ Create new</button>
</header>

<section class="metric-grid">
    <article class="metric-card"><span class="metric-icon lilac">◎</span><div><small>Active customers</small><strong><?= number_format($metrics['customers']) ?></strong><em>Customer accounts</em></div></article>
    <article class="metric-card"><span class="metric-icon blue">◇</span><div><small>Active orders</small><strong><?= number_format($metrics['orders']) ?></strong><em>Pending and active</em></div></article>
    <article class="metric-card"><span class="metric-icon amber">£</span><div><small>Outstanding</small><strong><?= htmlspecialchars($outstanding) ?></strong><em>Awaiting payment</em></div></article>
    <article class="metric-card"><span class="metric-icon green">✦</span><div><small>Open tickets</small><strong><?= number_format($metrics['tickets']) ?></strong><em>Need attention</em></div></article>
</section>

<section class="dashboard-grid">
    <article class="panel">
        <div class="panel-heading"><div><span class="eyebrow">Revenue</span><h2>Performance overview</h2></div><span class="pill">This month</span></div>
        <div class="empty-state"><span>↗</span><h3>Revenue reporting is ready</h3><p>Charts will populate as invoices and payments are recorded.</p></div>
    </article>
    <article class="panel quick-panel">
        <div class="panel-heading"><div><span class="eyebrow">Shortcuts</span><h2>Quick actions</h2></div></div>
        <a href="#"><span>◎</span><div><strong>Add a customer</strong><small>Create a new customer account</small></div><b>›</b></a>
        <a href="#"><span>◇</span><div><strong>Create an order</strong><small>Assign a package or service</small></div><b>›</b></a>
        <a href="#"><span>▤</span><div><strong>Raise an invoice</strong><small>Send a new payment request</small></div><b>›</b></a>
    </article>
</section>
