<?php

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Env;

$currentUser = Auth::user();
$appName = Env::get('APP_NAME', 'Veelox Digital');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title ?? 'Portal') ?> · <?= htmlspecialchars((string) $appName) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="/">
            <span class="brand-mark">V</span>
            <span><strong>Veelox</strong><small>Digital</small></span>
        </a>
        <nav class="nav-list" aria-label="Main navigation">
            <a class="active" href="/"><span>⌂</span> Dashboard</a>
            <a href="#"><span>◎</span> Customers</a>
            <a href="#"><span>▦</span> Plans &amp; packages</a>
            <a href="#"><span>◇</span> Orders</a>
            <a href="#"><span>▤</span> Invoices</a>
            <a href="#"><span>✦</span> Support tickets</a>
            <?php if (($currentUser['role'] ?? '') === 'admin'): ?>
                <a href="#"><span>↗</span> Reports</a>
                <a href="#"><span>⚙</span> Settings</a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-user">
            <div class="avatar"><?= htmlspecialchars(strtoupper(substr((string) ($currentUser['name'] ?? 'V'), 0, 1))) ?></div>
            <div><strong><?= htmlspecialchars((string) ($currentUser['name'] ?? 'User')) ?></strong><small><?= htmlspecialchars(ucfirst((string) ($currentUser['role'] ?? ''))) ?></small></div>
            <form action="/logout" method="post">
                <input type="hidden" name="_token" value="<?= htmlspecialchars(Csrf::token()) ?>">
                <button class="logout" type="submit" title="Sign out">↪</button>
            </form>
        </div>
    </aside>
    <main class="main-content">
        <?= $content ?>
    </main>
</div>
</body>
</html>
