<?php

declare(strict_types=1);

use App\Controllers\AuthController;
use App\Controllers\CustomerController;
use App\Controllers\DashboardController;

return [
    ['GET', '/', [DashboardController::class, 'index'], ['auth']],
    ['GET', '/login', [AuthController::class, 'showLogin'], ['guest']],
    ['POST', '/login', [AuthController::class, 'login'], ['guest', 'csrf']],
    ['POST', '/logout', [AuthController::class, 'logout'], ['auth', 'csrf']],
    ['GET', '/customers', [CustomerController::class, 'index'], ['auth', 'role:admin,staff']],
    ['GET', '/customers/create', [CustomerController::class, 'create'], ['auth', 'role:admin,staff']],
    ['POST', '/customers', [CustomerController::class, 'store'], ['auth', 'role:admin,staff', 'csrf']],
    ['GET', '/customers/{id}', [CustomerController::class, 'show'], ['auth', 'role:admin,staff']],
    ['GET', '/customers/{id}/edit', [CustomerController::class, 'edit'], ['auth', 'role:admin,staff']],
    ['POST', '/customers/{id}', [CustomerController::class, 'update'], ['auth', 'role:admin,staff', 'csrf']],
    ['POST', '/customers/{id}/archive', [CustomerController::class, 'archive'], ['auth', 'role:admin,staff', 'csrf']],
    ['POST', '/customers/{id}/portal-access', [CustomerController::class, 'createPortalAccess'], ['auth', 'role:admin,staff', 'csrf']],
];
